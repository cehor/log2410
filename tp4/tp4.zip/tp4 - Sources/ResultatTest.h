///////////////////////////////////////////////////////////
//  resultat_test.h
//  Implementation of the enum resultat_test
//  Created on:      27-oct.-2016 15:12:15
//  Original author: francois
///////////////////////////////////////////////////////////

#if !defined(RESULTAT_TEST__INCLUDED_)
#define RESULTAT_TEST__INCLUDED_

enum class ResultatTest { echec, succes };

#endif // RESULTAT_TEST__INCLUDED_